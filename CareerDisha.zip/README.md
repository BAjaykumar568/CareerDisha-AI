# CareerDisha AI — Working App Prototype

**Tagline:** From Confusion to Career Clarity  
**Assignment:** Jio AI Foundations — App Architect Capstone  
**Type:** Responsive web app (runs on Windows/macOS/Linux and mobile browsers)

## Quick start — no installation or coding

1. Extract the ZIP.
2. Double-click **index.html**.
3. Your browser opens CareerDisha AI. Click any sidebar or mobile navigation tab.
4. The app initially shows a **fictional demo student: Arjun Reddy**. Edit this in **My Profile**.

Works without a login, external AI API key, Python, or paid service. All changes are stored in that browser's `localStorage` when permitted. Keep a backup with **My Profile → Export my data**; exporting is currently a backup only (there is no import feature).

## Demo interactions to show during project evaluation

1. Open **My Roadmap** → choose a role, update skills and study hours → **Generate my roadmap**.
2. Check off a milestone; visit **Dashboard** and watch the progress update.
3. Open **Job Analyzer** → select **Python Dev** example → **Analyze job requirements**.
4. Review matched/missing skills → **Add gaps to roadmap**.
5. Explore **Learning Resources** and try **Disha Coach** suggested questions.
6. Open **My Profile** to save a learner's name and education, export data, reset, or delete browser data.

### Implemented features

- Five target roles: Python Developer, Data Analyst, AI/ML Engineer, Frontend Developer, Backend Developer.
- Editable self-reported skills and realistic milestone-based roadmaps.
- Adjustable weekly study hours, budget and learning pace.
- Manual progress tracking with persistent local storage.
- Job description keyword extraction, matched/possible missing skills (not a hiring score).
- Add skill gaps to the roadmap and track those practice activities.
- Curated learning links to external official docs and tutorials.
- Contextual offline Disha Coach, profile editor, export and reset/delete controls.
- Desktop sidebar, mobile bottom navigation and accessible labeled controls.

## Optional: connect a real AI model using Gemini

You can run the same app through a tiny Node.js server that calls the Gemini API privately. **This is optional**. A live LLM is **not included** in the offline prototype.

Install **Node.js 18+** then open a terminal inside this folder:

Windows PowerShell:

```powershell
$env:GEMINI_API_KEY="YOUR_GEMINI_API_KEY"
node server.js
```

Windows Command Prompt:

```cmd
set GEMINI_API_KEY=YOUR_GEMINI_API_KEY
node server.js
```

macOS / Linux:

```bash
GEMINI_API_KEY="YOUR_GEMINI_API_KEY" node server.js
```

Open **http://127.0.0.1:3000** and use **Disha Coach**. Set `GEMINI_MODEL` if you want to choose another model. Never paste your secret API key into `index.html`, browser developer tools, public code, or the app chat. The key is held server-side and only shared with Gemini via the server. API pricing, usage, and availability depend on your Gemini account and model.

If the API is unavailable or the key is absent, Disha Coach falls back to explicit demo guidance. The roadmap generator and job skill comparison remain local, rule-based functions — they are not secretly powered by Gemini even if Disha Coach has an API key.

## Important scope and privacy notes

- This is a **functional educational prototype**, not a production job placement platform.
- No employers, real-time job listings, course partners, or placement guarantee.
- Self-reported skills are **not validated proficiency**. Completion checkmarks are manually entered.
- Offline demo does not send student information to a server. Opening external learning links goes to third-party websites. The app itself does not need external fonts or libraries. If the optional server and Gemini API are enabled, coach prompts and minimal career context are sent to Gemini for response generation.
- `localStorage` is browser/device-specific and can be cleared by browser settings. Deleting local data loads a blank starter profile in the interface; server/API conversations are not retained by this app.
- To demonstrate publicly, host on HTTPS and use production authentication, privacy policy, security controls, and resilient API monitoring before accepting real personal data.
- The **original assignment only required an app blueprint**, so submit the six-section PDF for the assignment unless instructors explicitly accept a supplementary prototype.
